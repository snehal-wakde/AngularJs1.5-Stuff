var app = angular.module('MyApp', [
  'ionic',
  'MyApp.controllers',
  'MyApp.services'
  ]);

app.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    //StatusBar.styleDefault();
  });
});

app.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider

    .state('tab', {
      url: "/tab",
      abstract: true,
      templateUrl: 'tabs.html'
    })

    .state('tab.posts', {
      url: '/posts',
      views: {
        'tab-posts': {
          templateUrl: 'tab-posts.html',
          controller: 'PostsCtrl'
        },
      }
    })

    .state('tab.newpost', {
      url: '/newpost',
      views: {
        // 'tab-newpost': {
        'tab-posts': {
          templateUrl: 'tab-newpost.html',
          controller: 'NavCtrl'
        }
      }
    })

  .state('tab.view', 
  { 
    url: '/posts/:postId',
    views: {
      'tab-view': {
        templateUrl: 'tab-showpost.html',
        controller: 'PostViewCtrl'
      }
    }
  })
  
    .state('tab.account', {
      url: '/account',
      views: {
        'tab-account': {
          templateUrl: 'tab-account.html',
          controller: 'AccountCtrl'
        }
      }
    });

  $urlRouterProvider.otherwise('/tab/posts');

});