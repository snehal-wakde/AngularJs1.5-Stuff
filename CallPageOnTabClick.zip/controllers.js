var app = angular.module('MyApp.controllers', []);


app.controller('NavCtrl', function($scope, $location, $state, Post) {//, Auth) {
  $scope.post = {
    url: 'http://',
    title: ''
  };

  $scope.submitPost = function() {
    Post.create($scope.post).then(function(postId) {
      $scope.post = {
        url: 'http://',
        title: ''
      };
      $state.go('tab.newpost');
      //$location.path('/posts/' + postId);
    });
  };

  $scope.create = function() {
    $state.go('tab.newpost');
  };
  $scope.close = function() { 
     $state.go('tab.posts'); 
  };
  $scope.logout = function() {
    //Auth.logout();
    //$location.path('/auth/login');
  };
});  



app.controller('PostsCtrl', function($scope, $location, Post) {
  if ($location.path() === '/tab/posts') {
    $scope.posts = Post.all;
  }

  $scope.post = {
    url: 'http://',
    title: ''
  };

  $scope.deletePost = function(postId) {
    Post.delete(postId);
  };
});



app.controller('PostViewCtrl', function ($scope, $stateParams, Post) {
    $scope.post = Post.find($stateParams.postId);
});

app.controller('AccountCtrl', function($scope, $state) {
});