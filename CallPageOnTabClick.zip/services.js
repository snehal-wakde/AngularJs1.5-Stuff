var app = angular.module('MyApp.services', []);

app.factory('Post', function() {
  return {
    find : function(id) {
      this.posts[id];
    },
    
    add: function(post) {
      this.posts.push(
        {id: this.posts.length, url: post.url, title: post.title}
        );
    },
    
    posts: [
      {id: 0, url: "#/some-url/0", title: "How to do item A"}, 
      {id: 1, url: "#/some-url/1", title: "How to do item B"},
      {id: 2, url: "#/some-url/2", title: "YOLO"},
      ],
    
  };
  
});