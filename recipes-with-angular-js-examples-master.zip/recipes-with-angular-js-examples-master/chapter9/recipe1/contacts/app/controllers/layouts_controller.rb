class LayoutsController < ApplicationController
  def index
    render "layouts/application"
  end
end