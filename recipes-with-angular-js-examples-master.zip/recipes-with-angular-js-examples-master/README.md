# Recipes with Angular.js Example

Examples to accompany the book
[Recipes with Angular.js](http://leanpub.com/recipes-with-angular-js).

If you have questions or comments, open an issue or [email me](fdietz@gmail.com).

Most examples are using [angular-seed](https://github.com/angular/angular-seed) or [angular-express-seed](https://github.com/btford/angular-express-seed) as a bootstrap.
