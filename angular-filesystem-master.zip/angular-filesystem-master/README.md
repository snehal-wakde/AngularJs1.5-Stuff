angular-filesystem
==================

AngularJS Service implementation of the Web FileSystem API