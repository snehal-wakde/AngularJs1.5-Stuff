# Demonstration of AngularUI Router

Code and demo for the scotch.io tutorial

[AngularJS Routing Using UI-Router](http://scotch.io/tutorials/javascript/angular-routing-using-ui-router)