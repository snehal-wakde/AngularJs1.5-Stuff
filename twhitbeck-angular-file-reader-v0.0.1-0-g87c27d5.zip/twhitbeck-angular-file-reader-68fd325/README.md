angular-file-reader
===================

Provides access to FileReader api in angular
