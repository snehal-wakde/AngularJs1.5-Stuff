
# AngularJS Directive Controllers

by [Ben Nadel][1]

[View the demo on GitHub Pages][2]. This is an exploration of the use of Controllers in 
Directives as a means to facilitate inter-directive communication. 


[1]: http://www.bennadel.com
[2]: http://bennadel.github.com/AngularJS-Directive-Controllers