var app = angular.module('app', ['ngTouch', 'ui.grid', 'ui.grid.edit', 'addressFormatter']);

angular.module('addressFormatter', []).filter('address', function () {
  return function (input) {
      return input.street + ', ' + input.city + ', ' + input.state + ', ' + input.zip;
  };
});

app.controller('MainCtrl', ['$scope', '$http', function ($scope, $http) {
  $scope.gridOptions = {  };
  $scope.productList = [];
  var pList = {};
  $http.get('products.json').success(function(data) {
    console.log(data);
    for(var i = 0;  i < data.length; i++){
      console.log(data[i].name);
      pList = {name: data[i].name};
      $scope.productList.push(pList);
    }
    console.log("$scope.productList", $scope.productList);
    $scope.products = $scope.productList;
    $scope.gridOptions.columnDefs = [
      { name: 'id', enableCellEdit: false, width: '10%' },
      { name: 'name', displayName: 'Name (editable)', width: '30%' },
      { name: 'age', displayName: 'Age' , type: 'number', width: '10%' },
      { 
        name: 'gender', 
        displayName: 'Gender', 
        editableCellTemplate: 'ui-grid/dropdownEditor', 
        width: '20%',
        cellFilter: 'mapGender', 
        editDropdownValueLabel: 'gender',
        editDropdownOptionsArray: [
        { id: 1, gender: 'male' },
        { id: 2, gender: 'female' }
        ] 
      },
      { 
      	name: 'product', 
      	field: 'product.name',
      	enableCellEdit: true, 
      	editType: 'dropdown', 
      	editDropdownOptionsArray: $scope.products,
      	editableCellTemplate: 'ui-grid/dropdownEditor', 
      	editDropdownIdLabel: 'name',
        editDropdownValueLabel: 'name'
      }
    ];
  });

 $scope.msg = {};
console.log("$scope.productList", $scope.productList);
 $scope.gridOptions.onRegisterApi = function(gridApi){
    //set gridApi on scope
    $scope.gridApi = gridApi;
    gridApi.edit.on.afterCellEdit($scope,function(rowEntity, colDef, newValue, oldValue){
      $scope.msg.lastCellEdited = 'edited row id:' + rowEntity.id + ' Column:' + colDef.name + ' newValue:' + newValue + ' oldValue:' + oldValue ;
      $scope.msg.lastCellEdited = 'edited row id:' + rowEntity.id + ' Column:' + colDef.name + ' newValue:' + newValue + ' oldValue:' + oldValue ;
      console.log("productID: " + $scope.gridOptions.data[rowEntity.id].product.id);
      console.log("productName: " + $scope.gridOptions.data[rowEntity.id].product.name);
      console.log("user: " + $scope.gridOptions.data[rowEntity.id].name);
      $scope.$apply();
    });
  };

  $http.get('data.json')
    .success(function(data) {
      console.log("data : ", data[0].product.name);
      for(i = 0; i < data.length; i++){
        data[i].gender = data[i].gender==='male' ? 1 : 2;
      }
      $scope.gridOptions.data = data;
    });
}])


.filter('mapGender', function() {
  var genderHash = {
    1: 'male',
    2: 'female'
  };

  return function(input) {
    if (!input){
      return '';
    } else {
      return genderHash[input];
    }
  };
})
;
