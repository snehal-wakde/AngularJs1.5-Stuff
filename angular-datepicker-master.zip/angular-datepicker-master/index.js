require('./dist/index.js');
module.exports = 'datePicker';

